<form action="" method="post">
    Make: <input type="text" name="make" /><br />
    Model: <input type="text" name="model" /><br />
    Year: <input type="text" name="year" /><br />

    First name: <input type="text" name="first_name" /><br />
    Family name: <input type="text" name="family_name" /><br />

    Amount: <input type="text" name="amount" /><br />
    <input type="submit" name="submit" value="send it" />
</form>