<?php
http_response_code(404);
?>
<img src="view/error.jpg" />