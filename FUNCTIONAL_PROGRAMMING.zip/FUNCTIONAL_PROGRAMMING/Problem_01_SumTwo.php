<?php

$sumTwo = function ($a, $b)
{
    return $a + $b;
};

echo 'The sum is: '.$sumTwo(7.1234,7.4321);